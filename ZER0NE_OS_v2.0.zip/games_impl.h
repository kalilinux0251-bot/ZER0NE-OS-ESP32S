#ifndef GAMES_IMPL_H
#define GAMES_IMPL_H

#include "games.h"

// --- Snake mini-game ---
#define SNAKE_MAX 20
int snakeX[SNAKE_MAX], snakeY[SNAKE_MAX];
int snakeLen = 3;
int snakeDir = 0; // 0=right,1=down,2=left,3=up
int foodX = 0, foodY = 0;
bool snakeInit = false;
unsigned long snakeTick = 0;

void initSnake() {
  snakeLen = 3;
  snakeDir = 0;
  for (int i = 0; i < snakeLen; i++) {
    snakeX[i] = 10 - i;
    snakeY[i] = 4;
  }
  foodX = random(2, 14);
  foodY = random(2, 6);
  snakeInit = true;
}

void snake() {
  if (!snakeInit) initSnake();

  if (millis() - snakeTick < 300) return;
  snakeTick = millis();

  // Move body
  for (int i = snakeLen - 1; i > 0; i--) {
    snakeX[i] = snakeX[i-1];
    snakeY[i] = snakeY[i-1];
  }

  // Move head
  switch(snakeDir) {
    case 0: snakeX[0]++; break;
    case 1: snakeY[0]++; break;
    case 2: snakeX[0]--; break;
    case 3: snakeY[0]--; break;
  }

  // Wrap
  if (snakeX[0] >= 16) snakeX[0] = 0;
  if (snakeX[0] < 0) snakeX[0] = 15;
  if (snakeY[0] >= 8) snakeY[0] = 0;
  if (snakeY[0] < 0) snakeY[0] = 7;

  // Eat food
  if (snakeX[0] == foodX && snakeY[0] == foodY) {
    if (snakeLen < SNAKE_MAX) snakeLen++;
    score += 10;
    needSave = true;
    foodX = random(2, 14);
    foodY = random(2, 6);
  }
}

void drawSnake() {
  display.setCursor(0, 0);
  display.print(F("SNAKE  SC:"));
  display.println(score);

  // Draw border
  display.drawRect(0, 10, 128, 54, SSD1306_WHITE);

  // Draw food
  display.fillRect(foodX * 8, 10 + foodY * 6, 6, 4, SSD1306_WHITE);

  // Draw snake
  for (int i = 0; i < snakeLen; i++) {
    display.fillRect(snakeX[i] * 8, 10 + snakeY[i] * 6, 6, 4, SSD1306_WHITE);
  }
}

// --- Pong mini-game ---
int ballX = 64, ballY = 32;
int ballDX = 1, ballDY = 1;
int paddleY = 24;
bool pongInit = false;
unsigned long pongTick = 0;

void initPong() {
  ballX = 64; ballY = 32;
  ballDX = random(0, 2) ? 1 : -1;
  ballDY = random(0, 2) ? 1 : -1;
  paddleY = 24;
  pongInit = true;
}

void pong() {
  if (!pongInit) initPong();

  if (millis() - pongTick < 50) return;
  pongTick = millis();

  ballX += ballDX;
  ballY += ballDY;

  if (ballY <= 0 || ballY >= 63) ballDY = -ballDY;
  if (ballX >= 127) ballDX = -ballDX;

  // Paddle collision
  if (ballX <= 4 && ballY >= paddleY && ballY <= paddleY + 16) {
    ballDX = -ballDX;
    score += 5;
    needSave = true;
  }

  // AI paddle follows ball
  if (paddleY + 8 < ballY) paddleY += 2;
  if (paddleY + 8 > ballY) paddleY -= 2;
  if (paddleY < 0) paddleY = 0;
  if (paddleY > 48) paddleY = 48;

  // Miss = reset
  if (ballX < 0) {
    initPong();
  }
}

void drawPong() {
  display.setCursor(0, 0);
  display.print(F("PONG  SC:"));
  display.println(score);

  display.drawRect(0, 10, 128, 54, SSD1306_WHITE);
  display.fillCircle(ballX, 10 + ballY, 2, SSD1306_WHITE);
  display.fillRect(2, 10 + paddleY, 3, 16, SSD1306_WHITE);
  display.fillRect(123, 10 + paddleY, 3, 16, SSD1306_WHITE);
}

// --- Dodge mini-game ---
int playerX = 64, playerY = 50;
int obsX[3], obsY[3];
bool dodgeInit = false;
unsigned long dodgeTick = 0;

void initDodge() {
  playerX = 64; playerY = 50;
  for (int i = 0; i < 3; i++) {
    obsX[i] = random(10, 118);
    obsY[i] = random(-30, 0);
  }
  dodgeInit = true;
}

void dodge() {
  if (!dodgeInit) initDodge();

  if (millis() - dodgeTick < 60) return;
  dodgeTick = millis();

  // Auto-move player toward center
  if (playerX < 64) playerX += 1;
  if (playerX > 64) playerX -= 1;

  for (int i = 0; i < 3; i++) {
    obsY[i] += 2;
    if (obsY[i] > 64) {
      obsY[i] = random(-20, -5);
      obsX[i] = random(10, 118);
      score += 2;
      needSave = true;
    }

    // Collision
    if (abs(playerX - obsX[i]) < 8 && abs(playerY - obsY[i]) < 8) {
      score = max(0, score - 20);
      needSave = true;
      initDodge();
      return;
    }
  }
}

void drawDodge() {
  display.setCursor(0, 0);
  display.print(F("DODGE  SC:"));
  display.println(score);

  display.drawRect(0, 10, 128, 54, SSD1306_WHITE);
  display.fillRect(playerX - 4, playerY - 4, 8, 8, SSD1306_WHITE);

  for (int i = 0; i < 3; i++) {
    display.fillRect(obsX[i] - 4, obsY[i] - 4, 8, 8, SSD1306_WHITE);
  }
}

// --- Reaction mini-game ---
unsigned long reactStart = 0;
bool reactWaiting = false;
bool reactReady = false;
bool reactionInit = false;

void initReaction() {
  reactWaiting = false;
  reactReady = false;
  reactionInit = true;
}

void reaction() {
  if (!reactionInit) initReaction();

  if (!reactWaiting && !reactReady) {
    reactWaiting = true;
    reactStart = millis() + random(2000, 5000);
  }

  if (reactWaiting && millis() >= reactStart) {
    reactWaiting = false;
    reactReady = true;
  }
}

void drawReaction() {
  display.setCursor(0, 0);
  display.print(F("REACT  SC:"));
  display.println(score);

  display.setCursor(20, 30);
  if (reactWaiting) {
    display.println(F("WAIT..."));
  } else if (reactReady) {
    display.println(F("PRESS NOW!"));
  } else {
    display.println(F("READY?"));
  }
}

// --- Main game update/draw ---
void updateGame() {
  switch(gameId) {
    case 0: snake();    break;
    case 1: pong();     break;
    case 2: dodge();    break;
    case 3: reaction(); break;
  }
}

void drawGame() {
  switch(gameId) {
    case 0: drawSnake();    break;
    case 1: drawPong();     break;
    case 2: drawDodge();    break;
    case 3: drawReaction(); break;
  }
}

#endif
