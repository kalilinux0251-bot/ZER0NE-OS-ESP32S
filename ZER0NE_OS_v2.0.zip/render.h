#ifndef RENDER_H
#define RENDER_H

#include <Adafruit_SSD1306.h>
#include <Arduino.h>

extern Adafruit_SSD1306 display;

void initRender();
void renderFrame();

// Draw functions (NO logic, only rendering)
void drawMenu();
void drawGame();
void drawTerminal();
void drawGman();

#endif
