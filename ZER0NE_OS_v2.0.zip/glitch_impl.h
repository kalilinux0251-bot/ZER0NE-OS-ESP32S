#ifndef GLITCH_IMPL_H
#define GLITCH_IMPL_H

#include "glitch.h"

void glitchUpdate() {
  if (random(0, 200) == 1) {
    int y = random(0, 64);
    display.drawFastHLine(0, y, 128, SSD1306_WHITE);
  }
  if (random(0, 300) == 1) {
    int x = random(0, 128);
    display.drawFastVLine(x, 0, 64, SSD1306_WHITE);
  }
  if (random(0, 500) == 1) {
    // Random pixel block
    int x = random(0, 120);
    int y = random(0, 56);
    display.fillRect(x, y, random(4, 12), random(4, 12), SSD1306_WHITE);
  }
}

#endif
