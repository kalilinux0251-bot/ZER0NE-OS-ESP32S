#ifndef SYSTEM_CORE_IMPL_H
#define SYSTEM_CORE_IMPL_H

#include "system_core.h"

int state = STATE_MENU;
int gameId = 0;
int score = 0;
int secretFlag = 0;

int menuIndex = 0;
const int menuSize = 4;

void updateSystem() {
  switch(state) {
    case STATE_MENU:   updateMenu();     break;
    case STATE_GAME:   updateGame();     break;
    case STATE_TERMINAL: updateTerminal(); break;
    case STATE_BOSS:   updateGman();     break;
  }
}

void updateMenu() {
  // Menu logic: selection handled by input
  // Nothing to update continuously
}

void updateTerminal() {
  // Terminal logic placeholder
}

void updateGman() {
  // Boss fight logic placeholder
}

#endif
