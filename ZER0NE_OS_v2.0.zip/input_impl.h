#ifndef INPUT_IMPL_H
#define INPUT_IMPL_H

#include "input.h"
#include "system_core.h"

unsigned long pressTime = 0;
bool pressed = false;

void handleInput() {
  if (digitalRead(BTN) == LOW) {
    if (!pressed) {
      pressed = true;
      pressTime = millis();
    }
  } else {
    if (pressed) {
      unsigned long duration = millis() - pressTime;

      if (duration < 500) {
        // SHORT PRESS — navigate
        if (state == STATE_MENU) {
          menuIndex++;
          if (menuIndex >= menuSize) menuIndex = 0;
        } else {
          // In-game: cycle game mode
          gameId++;
          if (gameId > 3) gameId = 0;
        }
      } else {
        // LONG PRESS — select / back to menu
        if (state == STATE_MENU) {
          state = menuIndex;
        } else {
          state = STATE_MENU;
        }
      }

      pressed = false;
    }
  }
}

#endif
