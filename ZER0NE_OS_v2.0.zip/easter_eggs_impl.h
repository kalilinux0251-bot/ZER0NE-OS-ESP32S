#ifndef EASTER_EGGS_IMPL_H
#define EASTER_EGGS_IMPL_H

#include "easter_eggs.h"

void checkEasterEggs() {
  // Easter egg 1: High score in dodge
  if (score > 100 && gameId == 2 && secretFlag == 0) {
    secretFlag = 1;
    // Could trigger special effect here
  }

  // Easter egg 2: Secret sequence (placeholder)
  // if (stateSequence matches) { ... }
}

#endif
