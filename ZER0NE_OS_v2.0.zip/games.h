#ifndef GAMES_H
#define GAMES_H

#include <Arduino.h>
#include <Adafruit_SSD1306.h>

extern Adafruit_SSD1306 display;

extern int score;
extern int gameId;
extern bool needSave;

void snake();
void pong();
void dodge();
void reaction();

void runGame();
void updateGame();
void drawGame();

#endif
