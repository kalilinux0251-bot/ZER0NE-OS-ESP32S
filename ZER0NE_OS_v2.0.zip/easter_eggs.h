#ifndef EASTER_EGGS_H
#define EASTER_EGGS_H

#include <Arduino.h>
#include <Adafruit_SSD1306.h>

extern Adafruit_SSD1306 display;

extern int score;
extern int gameId;
extern int secretFlag;

void checkEasterEggs();

#endif
