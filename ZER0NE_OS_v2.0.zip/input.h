#ifndef INPUT_H
#define INPUT_H

#include <Arduino.h>

#define BTN 0

void handleInput();

#endif
