#ifndef SAVE_H
#define SAVE_H

#include <Arduino.h>
#include <EEPROM.h>

extern int score;
extern int gameId;
extern bool needSave;

void loadData();
void saveData();

#endif
