#ifndef RENDER_IMPL_H
#define RENDER_IMPL_H

#include "render.h"
#include "system_core.h"
#include "gman.h"

void initRender() {
  display.clearDisplay();
  display.setTextSize(1);
  display.setTextColor(SSD1306_WHITE);
  display.display();
}

void renderFrame() {
  display.clearDisplay();

  switch(state) {
    case STATE_MENU:     drawMenu();     break;
    case STATE_GAME:     drawGame();     break;
    case STATE_TERMINAL: drawTerminal(); break;
    case STATE_BOSS:     drawGman();     break;
  }

  // G-Man overlay (drawn on top if active)
  drawGmanOverlay();

  display.display();
}

void drawMenu() {
  display.setCursor(0, 0);
  display.println(F("ZER0NE OS v2.0"));
  display.println(F(""));

  const char* items[] = {"MENU", "GAME", "TERM", "BOSS"};
  for (int i = 0; i < menuSize; i++) {
    if (i == menuIndex) {
      display.print(F("> "));
    } else {
      display.print(F("  "));
    }
    display.println(items[i]);
  }

  display.println(F(""));
  display.print(F("SCORE: "));
  display.println(score);
}

void drawTerminal() {
  display.setCursor(0, 0);
  display.println(F("> ACCESSING..."));
  display.println(F("  DATA CORRUPTED"));
  display.println(F("  [REDACTED]"));
  display.println(F(""));
  display.println(F("  HOLD BTN TO EXIT"));
}

void drawGman() {
  display.setCursor(0, 0);
  display.println(F("G-MAN:"));
  display.println(F("  nu trebuia..."));
  display.println(F("  sa fii aici."));
  display.println(F(""));
  display.println(F("  HOLD BTN TO EXIT"));
}

#endif
