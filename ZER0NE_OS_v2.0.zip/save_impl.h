#ifndef SAVE_IMPL_H
#define SAVE_IMPL_H

#include "save.h"

bool needSave = false;

void loadData() {
  EEPROM.get(0, score);
  EEPROM.get(4, gameId);

  // Validate loaded data
  if (score < 0 || score > 99999) score = 0;
  if (gameId < 0 || gameId > 3) gameId = 0;
}

void saveData() {
  if (!needSave) return;

  EEPROM.put(0, score);
  EEPROM.put(4, gameId);
  EEPROM.commit();

  needSave = false;
}

#endif
