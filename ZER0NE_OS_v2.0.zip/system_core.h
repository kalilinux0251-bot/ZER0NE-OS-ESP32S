#ifndef SYSTEM_CORE_H
#define SYSTEM_CORE_H

#include <Arduino.h>
#include <Adafruit_SSD1306.h>

extern Adafruit_SSD1306 display;

// --- State Machine ---
enum State {
  STATE_MENU = 0,
  STATE_GAME = 1,
  STATE_TERMINAL = 2,
  STATE_BOSS = 3,
  STATE_COUNT
};

extern int state;
extern int gameId;
extern int score;
extern int secretFlag;

// --- Menu Navigation ---
extern int menuIndex;
extern const int menuSize;

void updateSystem();

// Update functions (logic only, NO drawing)
void updateMenu();
void updateGame();
void updateTerminal();
void updateGman();

#endif
