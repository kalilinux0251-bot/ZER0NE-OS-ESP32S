#ifndef INVENTORY_H
#define INVENTORY_H

#include <Arduino.h>

extern char inventory[3][12];
extern int invCount;

void addItem(const char* item);
void clearInventory();

#endif
