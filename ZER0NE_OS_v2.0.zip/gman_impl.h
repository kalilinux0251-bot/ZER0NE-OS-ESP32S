#ifndef GMAN_IMPL_H
#define GMAN_IMPL_H

#include "gman.h"

bool gmanActive = false;
unsigned long gmanTime = 0;
unsigned long gmanCheckTimer = 0;

void gmanUpdate() {
  if (millis() - gmanCheckTimer > 6000) {
    gmanCheckTimer = millis();

    if (!gmanActive && random(0, 120) == 1) {
      gmanActive = true;
      gmanTime = millis();
    }
  }

  if (gmanActive && millis() - gmanTime > 2000) {
    gmanActive = false;
  }
}

void drawGmanOverlay() {
  if (!gmanActive) return;

  // Semi-transparent effect via inverted text area
  display.fillRect(10, 20, 108, 24, SSD1306_BLACK);
  display.drawRect(10, 20, 108, 24, SSD1306_WHITE);
  display.setCursor(16, 26);
  display.print(F("G-MAN: te observ..."));
}

#endif
