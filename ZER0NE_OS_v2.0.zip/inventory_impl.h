#ifndef INVENTORY_IMPL_H
#define INVENTORY_IMPL_H

#include "inventory.h"
#include <string.h>

char inventory[3][12];
int invCount = 0;

void addItem(const char* item) {
  if (invCount < 3 && item != nullptr) {
    strncpy(inventory[invCount], item, 11);
    inventory[invCount][11] = '\0';
    invCount++;
  }
}

void clearInventory() {
  invCount = 0;
  for (int i = 0; i < 3; i++) {
    inventory[i][0] = '\0';
  }
}

#endif
