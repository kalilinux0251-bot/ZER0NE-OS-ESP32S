#ifndef GLITCH_H
#define GLITCH_H

#include <Arduino.h>
#include <Adafruit_SSD1306.h>

extern Adafruit_SSD1306 display;

void glitchUpdate();

#endif
