#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include <EEPROM.h>

// --- Headers ---
#include "system_core.h"
#include "input.h"
#include "render.h"
#include "games.h"
#include "gman.h"
#include "inventory.h"
#include "glitch.h"
#include "save.h"
#include "easter_eggs.h"

// --- Implementations ---
#include "system_core_impl.h"
#include "input_impl.h"
#include "render_impl.h"
#include "games_impl.h"
#include "gman_impl.h"
#include "inventory_impl.h"
#include "glitch_impl.h"
#include "save_impl.h"
#include "easter_eggs_impl.h"

// --- Global Display ---
Adafruit_SSD1306 display(128, 64, &Wire, -1);

void setup() {
  pinMode(BTN, INPUT_PULLUP);

  if (!display.begin(SSD1306_SWITCHCAPVCC, 0x3C)) {
    // OLED init failed
    for (;;);
  }

  display.clearDisplay();
  display.setTextSize(1);
  display.setTextColor(SSD1306_WHITE);
  display.setCursor(0, 0);
  display.println(F("ZER0NE OS v2.0"));
  display.println(F("LOADING..."));
  display.display();

  EEPROM.begin(512);
  loadData();
  initRender();

  delay(500);
}

void loop() {
  handleInput();
  updateSystem();
  renderFrame();
  gmanUpdate();
  glitchUpdate();
  checkEasterEggs();
  saveData();
  delay(16);  // ~60 FPS
}
