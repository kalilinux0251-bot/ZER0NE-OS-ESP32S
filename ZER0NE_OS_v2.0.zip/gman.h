#ifndef GMAN_H
#define GMAN_H

#include <Arduino.h>
#include <Adafruit_SSD1306.h>

extern Adafruit_SSD1306 display;

void gmanUpdate();
void drawGmanOverlay();

#endif
